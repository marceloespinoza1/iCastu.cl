<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_flickr
 */
class WPBakeryShortCode_Vc_Flickr extends WPBakeryShortCode {
}
